/*
Karen Nanamy Kamo - NUSP: 15495932 
Rebeca de Oliveira Silva - NUSP: 11963923
*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#include "structs.h"
#include "ler_arq.h"
#include "escrever_arq.h"
#include "funcionalidades.h"
#include "uteis.h"

/* ================================================================================

******************************FUNCIONALIDADE 10************************************

===================================================================================*/ 
/* Funcionalidades: 
  1. Abrir arquivo de dados para leitura
  2. Criar e inicializar o grafo
  3. Ler todo o arquivo de dados para guardar os vértices
  4. Ler todo o arquivo de dados para guardar as arestas
  5. Impressão do grafo
  6. Liberação da memória e close
*/

void dijkstra() {
  
}

